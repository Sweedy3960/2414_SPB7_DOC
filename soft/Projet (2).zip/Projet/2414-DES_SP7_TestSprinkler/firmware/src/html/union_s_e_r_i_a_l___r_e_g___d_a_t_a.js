var union_s_e_r_i_a_l___r_e_g___d_a_t_a =
[
    [ "ALARRM_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a7084ffba9e347a09e917a95b2036c526", null ],
    [ "ALARRM_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a8d5250a3ac5ba8397372ffabb242dbaf", null ],
    [ "cmd_leds", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a72fb5d02ae1860d3c52620ab3254e533", null ],
    [ "DERR_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a77bce07d7f84c154f8f997bafdc7bfde", null ],
    [ "DERR_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#aaef1e94f2681c09821947d5a0369082f", null ],
    [ "FREE_IN1_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a9a59acdbebdccba7c6cc0e8f8a2499d3", null ],
    [ "FREE_IN1_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a52d45b8681cbd68987dfef038aaeb41e", null ],
    [ "FREE_IN2_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#af8da9ad61241aba3e037a86a11349e92", null ],
    [ "FREE_IN2_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#ab182c695986055bfb7ceebd750ca5e07", null ],
    [ "FREE_IN3_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#ad471fb944ede3fe9ea9d4858162a367c", null ],
    [ "FREE_IN3_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a6edb0e056c6ead698971b1918aaffc26", null ],
    [ "FREE_IN4_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a77968ab91446c321e37e6dc583825fe1", null ],
    [ "FREE_IN4_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a02f1b01cc6debdf3e7a6a052b97dfb10", null ],
    [ "FREE_IN5_LED", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#ae0687bc58afa748210b0a8d0b0f67e08", null ],
    [ "FREE_IN5_LED_SAVE", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#ac412151e4d842e8040712acfc640a548", null ],
    [ "led11", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a6d7ac0971da9a447d2923a116edc4aac", null ],
    [ "led8", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a5bb136298921ff01ffe8127416761375", null ],
    [ "state", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html#a31d906a47a47f4b6d30f6d1c8197e51c", null ]
];