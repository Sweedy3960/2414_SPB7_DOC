var struct_conf_in_switchs =
[
    [ "Ain1_conf", "struct_conf_in_switchs.html#a2a5e3e1cc77c11c86af11f95d04946eb", null ],
    [ "Ain2_conf", "struct_conf_in_switchs.html#af61f187d11f5f9193aa8f0ac116d2faa", null ],
    [ "Ain3_conf", "struct_conf_in_switchs.html#a4abfb19c11ff556b16df8359d0dedde3", null ],
    [ "FreeIn1_conf", "struct_conf_in_switchs.html#ab203b62f351dfbbbf00a96a143c62fe5", null ],
    [ "FreeIn2_conf", "struct_conf_in_switchs.html#a07f34869e40398f10df3bfba04c564ea", null ],
    [ "FreeIn3_conf", "struct_conf_in_switchs.html#a85232de9f2793824e3df28c9c76abed6", null ],
    [ "FreeIn4_conf", "struct_conf_in_switchs.html#aa56f995ba678fe6faa19bc5813d11dcc", null ],
    [ "FreeIn5_conf", "struct_conf_in_switchs.html#a16a8db661a63be19b2b827ac431245f4", null ],
    [ "SPBIn1_conf", "struct_conf_in_switchs.html#a6adc6882848f7ceb181fb098c3c81713", null ],
    [ "SPBIn2_conf", "struct_conf_in_switchs.html#aaf12fb10cfb9814cd2d2f2eb7cc89353", null ],
    [ "SPBIn3_conf", "struct_conf_in_switchs.html#af733a950b97916f5fc378e821f3b2ed2", null ]
];