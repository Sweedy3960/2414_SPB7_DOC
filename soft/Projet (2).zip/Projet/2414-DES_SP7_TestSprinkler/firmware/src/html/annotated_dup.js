var annotated_dup =
[
    [ "APP_DATA", "struct_a_p_p___d_a_t_a.html", "struct_a_p_p___d_a_t_a" ],
    [ "APP_FAT_DATA", "struct_a_p_p___f_a_t___d_a_t_a.html", "struct_a_p_p___f_a_t___d_a_t_a" ],
    [ "ConfInSwitchs", "struct_conf_in_switchs.html", "struct_conf_in_switchs" ],
    [ "fifo", "structfifo.html", "structfifo" ],
    [ "mcp79411_alarm", "structmcp79411__alarm.html", "structmcp79411__alarm" ],
    [ "mcp79411_ALARMS", "unionmcp79411___a_l_a_r_m_s.html", "unionmcp79411___a_l_a_r_m_s" ],
    [ "mcp79411_CONTROL", "unionmcp79411___c_o_n_t_r_o_l.html", "unionmcp79411___c_o_n_t_r_o_l" ],
    [ "mcp79411_obj", "structmcp79411__obj.html", "structmcp79411__obj" ],
    [ "mcp79411_OSCTRIM", "unionmcp79411___o_s_c_t_r_i_m.html", "unionmcp79411___o_s_c_t_r_i_m" ],
    [ "mcp79411_time", "structmcp79411__time.html", "structmcp79411__time" ],
    [ "mcp79411_TIME_KEEPING", "unionmcp79411___t_i_m_e___k_e_e_p_i_n_g.html", "unionmcp79411___t_i_m_e___k_e_e_p_i_n_g" ],
    [ "MUTEX_t", "struct_m_u_t_e_x__t.html", "struct_m_u_t_e_x__t" ],
    [ "S_ADCResults", "struct_s___a_d_c_results.html", "struct_s___a_d_c_results" ],
    [ "S_AT42QT2120", "struct_s___a_t42_q_t2120.html", "struct_s___a_t42_q_t2120" ],
    [ "S_Descr_I2C_SM", "struct_s___descr___i2_c___s_m.html", "struct_s___descr___i2_c___s_m" ],
    [ "SERIAL_REG_DATA", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html", "union_s_e_r_i_a_l___r_e_g___d_a_t_a" ],
    [ "StruMess", "struct_stru_mess.html", "struct_stru_mess" ],
    [ "SwithcConfig", "struct_swithc_config.html", "struct_swithc_config" ],
    [ "U_manip16", "union_u__manip16.html", "union_u__manip16" ]
];