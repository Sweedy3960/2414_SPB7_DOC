var struct_s___descr___i2_c___s_m =
[
    [ "DebugCode", "struct_s___descr___i2_c___s_m.html#a8085e3a71e809f383943901705799ca0", null ],
    [ "I2cMainSM", "struct_s___descr___i2_c___s_m.html#ad792a3668b51e7ffa32c976b75d84b94", null ],
    [ "I2cSeqSM", "struct_s___descr___i2_c___s_m.html#af033418484be26160089676f3eb4f433", null ]
];