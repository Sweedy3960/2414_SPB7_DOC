var unionmcp79411___c_o_n_t_r_o_l =
[
    [ "ALM0EN", "unionmcp79411___c_o_n_t_r_o_l.html#ad0af98f388b2d040251c849cd89ea173", null ],
    [ "ALM1EN", "unionmcp79411___c_o_n_t_r_o_l.html#a32f3dd957233db4e084ad5399ecb5935", null ],
    [ "bits", "unionmcp79411___c_o_n_t_r_o_l.html#a50c4b2d41268c92db00fec4f10931d97", null ],
    [ "CRSTRIM", "unionmcp79411___c_o_n_t_r_o_l.html#a35c4199167867a0effcf064323ee81b2", null ],
    [ "ctrl_byte", "unionmcp79411___c_o_n_t_r_o_l.html#a530f89db1c7efb161a9779d6526e52d3", null ],
    [ "EXTOSC", "unionmcp79411___c_o_n_t_r_o_l.html#ac26624524773b14d08bf9cd3b9310a4d", null ],
    [ "OUT", "unionmcp79411___c_o_n_t_r_o_l.html#a247b3e3bc75be4d1d80f1f5b19e21020", null ],
    [ "SQWEN", "unionmcp79411___c_o_n_t_r_o_l.html#aaa80e3ac1655414187143b04e15b8110", null ],
    [ "SQWFS", "unionmcp79411___c_o_n_t_r_o_l.html#af54106109ea3c3a373f28444c11bfba8", null ]
];