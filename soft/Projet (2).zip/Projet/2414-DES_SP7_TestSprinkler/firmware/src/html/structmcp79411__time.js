var structmcp79411__time =
[
    [ "date", "structmcp79411__time.html#aa0bfdc26f9cd0c0fcbfcc16f3cd99f47", null ],
    [ "hour", "structmcp79411__time.html#a3570bc91d88c62253caf1ab72a31bc5f", null ],
    [ "min", "structmcp79411__time.html#aac77aba6e1f35470054a534c37697837", null ],
    [ "mth", "structmcp79411__time.html#a54cd381ec959d258898a1b4ec7fdd96b", null ],
    [ "sec", "structmcp79411__time.html#a3ff7236d2fe59dd75a1ced740b42e6e1", null ],
    [ "wkday", "structmcp79411__time.html#a06515210e83423140947af0e68f16d28", null ],
    [ "year", "structmcp79411__time.html#a974714396b722bced5b6e031be077650", null ]
];