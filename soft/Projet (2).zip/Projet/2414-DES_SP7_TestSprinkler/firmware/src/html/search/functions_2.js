var searchData=
[
  ['bsp_5finitadc10_0',['BSP_InitADC10',['../_mc32_driver_adc_8c.html#ab8f2c4611b41e63055e35004ea2341e3',1,'BSP_InitADC10(void):&#160;Mc32DriverAdc.c'],['../_mc32_driver_adc_8h.html#ab8f2c4611b41e63055e35004ea2341e3',1,'BSP_InitADC10(void):&#160;Mc32DriverAdc.c']]],
  ['bsp_5freadalladc_1',['BSP_ReadAllADC',['../_mc32_driver_adc_8c.html#a36f58dfc74e1e275e60c920f876974db',1,'BSP_ReadAllADC():&#160;Mc32DriverAdc.c'],['../_mc32_driver_adc_8h.html#a36f58dfc74e1e275e60c920f876974db',1,'BSP_ReadAllADC():&#160;Mc32DriverAdc.c']]]
];
