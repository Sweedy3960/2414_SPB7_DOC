var searchData=
[
  ['slider_5foption_0',['SLIDER_OPTION',['../_p_i_c32130___a_t42_q_t2120___i2_c_8h.html#a1cb16479a962ff63f99d60a8be50352d',1,'PIC32130_AT42QT2120_I2C.h']]],
  ['slider_5fposition_1',['SLIDER_POSITION',['../_p_i_c32130___a_t42_q_t2120___i2_c_8h.html#a22d4669d15b68c291c8a4ea6fa5f4317',1,'PIC32130_AT42QT2120_I2C.h']]],
  ['stx_5fcode_2',['STX_code',['../_mc32gest___r_s232_8c.html#a875e32598663495e97588e7baaeafdfd',1,'Mc32gest_RS232.c']]]
];
