var searchData=
[
  ['wheel_5fenable_0',['WHEEL_ENABLE',['../_p_i_c32130___a_t42_q_t2120___i2_c_8h.html#a9cb36f8067a6f77b9d7173ea7eba4fb2',1,'PIC32130_AT42QT2120_I2C.h']]]
];
