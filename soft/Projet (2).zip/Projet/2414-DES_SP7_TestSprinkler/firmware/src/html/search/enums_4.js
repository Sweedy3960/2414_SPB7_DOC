var searchData=
[
  ['mcp79411_5falarm_5fchannel_0',['mcp79411_alarm_channel',['../mcp79411_8h.html#a3c6ed0c6f7309029270d232ebfbd4e04',1,'mcp79411.h']]],
  ['mcp79411_5falarm_5fmode_1',['mcp79411_alarm_mode',['../mcp79411_8h.html#a9e0b5c5bf2e2d00b3eedc532858bc7a9',1,'mcp79411.h']]]
];
