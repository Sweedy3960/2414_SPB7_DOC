var searchData=
[
  ['confinswitchs_0',['ConfInSwitchs',['../struct_conf_in_switchs.html',1,'']]]
];
