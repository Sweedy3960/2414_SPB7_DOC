var searchData=
[
  ['app_5fdata_0',['APP_DATA',['../struct_a_p_p___d_a_t_a.html',1,'']]],
  ['app_5ffat_5fdata_1',['APP_FAT_DATA',['../struct_a_p_p___f_a_t___d_a_t_a.html',1,'']]]
];
