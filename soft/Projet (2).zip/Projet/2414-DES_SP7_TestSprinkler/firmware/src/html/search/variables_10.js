var searchData=
[
  ['usarthandle_0',['usartHandle',['../app_8c.html#ad6d17d48fdff77c90488018e4021b515',1,'app.c']]]
];
