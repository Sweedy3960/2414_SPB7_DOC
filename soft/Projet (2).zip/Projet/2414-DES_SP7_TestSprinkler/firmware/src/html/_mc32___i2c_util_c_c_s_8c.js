var _mc32___i2c_util_c_c_s_8c =
[
    [ "I2C_CLOCK_FAST", "_mc32___i2c_util_c_c_s_8c.html#a7ae27275f20f4375997b8cbe1fe5fa3b", null ],
    [ "I2C_CLOCK_SLOW", "_mc32___i2c_util_c_c_s_8c.html#a0533c4883fc02455d2eee66ecd290136", null ],
    [ "KIT_I2C_BUS", "_mc32___i2c_util_c_c_s_8c.html#a31d82e34ecb2a371cd299049304f964d", null ],
    [ "i2c_init", "_mc32___i2c_util_c_c_s_8c.html#ae66465ee5e1b6c243b89bf5eb84280ad", null ],
    [ "i2c_read", "_mc32___i2c_util_c_c_s_8c.html#a8665061bf5ef45de3774a98c6f8c0021", null ],
    [ "i2c_reStart", "_mc32___i2c_util_c_c_s_8c.html#a02bfecef74beba2239cf086fe53896a3", null ],
    [ "i2c_start", "_mc32___i2c_util_c_c_s_8c.html#af104fa2713ad2cfe4f993bdd2ec22c46", null ],
    [ "i2c_stop", "_mc32___i2c_util_c_c_s_8c.html#ad35d4e4f52ca74b503d5e5e1e0a3f5f3", null ],
    [ "i2c_write", "_mc32___i2c_util_c_c_s_8c.html#aa089a0bc7250c164c807807978c21fae", null ],
    [ "I2cBrg", "_mc32___i2c_util_c_c_s_8c.html#a6ec2ac457d1b066ba80c4cd17f05edef", null ],
    [ "I2cConReg", "_mc32___i2c_util_c_c_s_8c.html#a306a8d03dd3ef42d1e986289df959d3f", null ]
];