var _mc32gest_i2c_seeprom_8h =
[
    [ "I2C_InitMCP79411", "_mc32gest_i2c_seeprom_8h.html#a3306f29c8c0f0473c7e00dbacb17a983", null ],
    [ "I2C_ReadSEEPROM", "_mc32gest_i2c_seeprom_8h.html#abe4c03a9abd92ea8537de7ea02d71003", null ],
    [ "I2C_WriteSEEPROM", "_mc32gest_i2c_seeprom_8h.html#ad4f4818d62f573fd6b0715977c242c0c", null ]
];