/**
 * @file mcp79411_interface.c
 * @author jozochen (jozocyz@hotmail.com)
 * @brief 
 * @date 2020-02-11
 * @copyright Apache License 2.0
 *            jozochen (jozocyz@hotmail.com) Copyright (c) 2020
 */
#include "mcp79411_interface.h"
#include "Mc32_I2cUtilCCS.h"

/**
 * @brief (Exemple) Fonction d'écriture I2C EEPROM pour le MCP79411 (commentée).
 *
 * @param tx_buffer Pointeur vers le buffer de données à écrire.
 * @param len Nombre d'octets à écrire.
 * @return int 0 si succès, -1 en cas d'échec.
 */
// int mcp79411_eep_iic_write(unsigned char *tx_buffer, short len);

/**
 * @brief (Exemple) Fonction de lecture I2C EEPROM pour le MCP79411 (commentée).
 *
 * @param rx_buffer Pointeur vers le buffer de réception.
 * @param len Nombre d'octets à lire.
 * @return int 0 si succès, -1 en cas d'échec.
 */
// int mcp79411_eep_iic_read(unsigned char *rx_buffer, short len);
