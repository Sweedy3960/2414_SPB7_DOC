var _mc32gest___r_s232_8h =
[
    [ "MAXMSGFAUX", "_mc32gest___r_s232_8h.html#a3fc330c2bdfdecefba5c67b50a7295e7", null ],
    [ "InitFifoComm", "_mc32gest___r_s232_8h.html#a2d69784a459e16a762705f2d7c0c5665", null ],
    [ "SendMessage", "_mc32gest___r_s232_8h.html#a9942400bfd56594e50487c705c8240a7", null ],
    [ "descrFifoRX", "_mc32gest___r_s232_8h.html#a0769dca91fb15b42f540c7b5111e25d2", null ],
    [ "descrFifoTX", "_mc32gest___r_s232_8h.html#aad4684d4f6da1ce70998e982331c86a5", null ]
];