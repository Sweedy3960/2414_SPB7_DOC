var struct_a_p_p___f_a_t___d_a_t_a =
[
    [ "DATA_BUFFER_ALIGN", "struct_a_p_p___f_a_t___d_a_t_a.html#a83dfbedcc693107e7f654a84fc5a7784", null ],
    [ "fileHandle", "struct_a_p_p___f_a_t___d_a_t_a.html#a3edb99262bcec7d4a2bb79fe1b3e86f2", null ],
    [ "fileHandle1", "struct_a_p_p___f_a_t___d_a_t_a.html#a68506e43221faf0517391077e245515a", null ],
    [ "nBytesRead", "struct_a_p_p___f_a_t___d_a_t_a.html#a4c9da3da10333d10387341be2833e928", null ],
    [ "nBytesToWrite", "struct_a_p_p___f_a_t___d_a_t_a.html#a66eb867794f611877f71c96ef02941e0", null ],
    [ "nBytesWritten", "struct_a_p_p___f_a_t___d_a_t_a.html#add2640bdbd91f68492ba39b0e15e280c", null ],
    [ "state", "struct_a_p_p___f_a_t___d_a_t_a.html#a2bbbb2e07c93810c3f11111ec7819b7c", null ]
];