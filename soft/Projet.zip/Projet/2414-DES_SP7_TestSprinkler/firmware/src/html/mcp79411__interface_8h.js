var mcp79411__interface_8h =
[
    [ "MCP79411_EEPROM_R", "mcp79411__interface_8h.html#a8126d54e38aa8fd72f762b0d86793eec", null ],
    [ "MCP79411_EEPROM_W", "mcp79411__interface_8h.html#ae7d901256aeec6b771342ffdd2c509e7", null ],
    [ "NULL_PTR", "mcp79411__interface_8h.html#a530f11a96e508d171d28564c8dc20942", null ],
    [ "mcp79411_eep_iic_read", "mcp79411__interface_8h.html#ae060c2d123d8b79972bd6213914c819f", null ],
    [ "mcp79411_eep_iic_write", "mcp79411__interface_8h.html#a52853704bfe8ff87ba67d9e6ee13bf14", null ],
    [ "mcp79411_rtc_iic_read", "mcp79411__interface_8h.html#abb05f6811123d1be40bc21fe1b8b5074", null ],
    [ "mcp79411_rtc_iic_write", "mcp79411__interface_8h.html#add5e3576881b1a5553a971d87ddbe8d1", null ]
];