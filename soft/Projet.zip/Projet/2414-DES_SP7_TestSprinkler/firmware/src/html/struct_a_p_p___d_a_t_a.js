var struct_a_p_p___d_a_t_a =
[
    [ "APP_DelayTimeIsRunning", "struct_a_p_p___d_a_t_a.html#a3b98f7c2463a4ee686752b1b9577a022", null ],
    [ "AppDelay", "struct_a_p_p___d_a_t_a.html#a17a3cc95c0d2a70aedea4e7d50fd3ba7", null ],
    [ "appMutex", "struct_a_p_p___d_a_t_a.html#a135ad94f246c9990576e183800df2397", null ],
    [ "cmdRealayOut", "struct_a_p_p___d_a_t_a.html#a1262446d553b67fd5ab69650d1b578c0", null ],
    [ "state", "struct_a_p_p___d_a_t_a.html#a5e301beaf2d55ccc56dfcf3943d310fc", null ],
    [ "sysLeds", "struct_a_p_p___d_a_t_a.html#aee7ccbdc60708d03e28215cc98e6977c", null ],
    [ "SySwitch", "struct_a_p_p___d_a_t_a.html#a6d12f5d530d8f877a04340e2f7d867ad", null ],
    [ "timeofRTC", "struct_a_p_p___d_a_t_a.html#ac9aff2c82e28d67ac00d682b76c1bb62", null ],
    [ "valAD", "struct_a_p_p___d_a_t_a.html#a6852c02f57797573b81c7b93353ce022", null ]
];