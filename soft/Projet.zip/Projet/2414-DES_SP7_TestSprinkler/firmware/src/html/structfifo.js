var structfifo =
[
    [ "fifoSize", "structfifo.html#ae41458656c44d1c3c827dde8ee29b298", null ],
    [ "pDebFifo", "structfifo.html#abeda917683e579be43522a6040a7a0ab", null ],
    [ "pFinFifo", "structfifo.html#a020a790c0fd625fe9c1f45cde49eccf0", null ],
    [ "pRead", "structfifo.html#a6422bf7f4dc9d867313e67aa807e1792", null ],
    [ "pWrite", "structfifo.html#a036dee8146e72ad3c67b70ea4d078228", null ]
];