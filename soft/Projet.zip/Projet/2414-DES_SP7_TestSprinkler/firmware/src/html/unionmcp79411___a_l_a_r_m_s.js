var unionmcp79411___a_l_a_r_m_s =
[
    [ "ALMPOL", "unionmcp79411___a_l_a_r_m_s.html#aff4c4522b40f90fb8ab0eb7258cc50e9", null ],
    [ "ALMXDATE_bits", "unionmcp79411___a_l_a_r_m_s.html#a97d90547bac3ecd1825549e2130e5575", null ],
    [ "ALMXHOUR_bits", "unionmcp79411___a_l_a_r_m_s.html#aa3d2597ed9593af71e417b5a33019466", null ],
    [ "ALMXIF", "unionmcp79411___a_l_a_r_m_s.html#acd6609681a96ca25a1dff0f04e287446", null ],
    [ "ALMXMIN_bits", "unionmcp79411___a_l_a_r_m_s.html#aaa74f675342507f7f95b01c175412e32", null ],
    [ "ALMXMSK", "unionmcp79411___a_l_a_r_m_s.html#a976569b60aae2ff3767169ebbd00be06", null ],
    [ "ALMXMTH_bits", "unionmcp79411___a_l_a_r_m_s.html#aa91a0b675215f9d284d16b64989c45e7", null ],
    [ "ALMXSEC_bits", "unionmcp79411___a_l_a_r_m_s.html#a5714d44338ae1e06e9bba776f0cf3512", null ],
    [ "ALMXWKDAY_bits", "unionmcp79411___a_l_a_r_m_s.html#a16a44be7aa32162a624be862a6c23443", null ],
    [ "AM_PM", "unionmcp79411___a_l_a_r_m_s.html#a26206c4de8dc5a04f4e80d7e49221728", null ],
    [ "b12_24", "unionmcp79411___a_l_a_r_m_s.html#a194903a2354f91120ef22eb45ceba067", null ],
    [ "bytes", "unionmcp79411___a_l_a_r_m_s.html#a94e0ae983bb8933e43325e73f7356dde", null ],
    [ "DATE", "unionmcp79411___a_l_a_r_m_s.html#a8cb0681aaef4ccb42ef41321f2ed7dfc", null ],
    [ "HOUR", "unionmcp79411___a_l_a_r_m_s.html#ac1b34e87c3b24929d2075519845a9e32", null ],
    [ "MIN", "unionmcp79411___a_l_a_r_m_s.html#ac6bf19e173885e4bc2b610105154a0e1", null ],
    [ "MTH", "unionmcp79411___a_l_a_r_m_s.html#afd8cc5a2c3c8ba541961c0b745f269da", null ],
    [ "regs", "unionmcp79411___a_l_a_r_m_s.html#a73c49e91aaf6bcf5c32202f435635afe", null ],
    [ "RES", "unionmcp79411___a_l_a_r_m_s.html#a869d53342ff857c00a887e40bbe44555", null ],
    [ "SEC", "unionmcp79411___a_l_a_r_m_s.html#af04bb7dfeae1479f7894e30cb3c07fb0", null ],
    [ "WKDAY", "unionmcp79411___a_l_a_r_m_s.html#ae7f88a83463b93943fb9016284b2f32a", null ]
];