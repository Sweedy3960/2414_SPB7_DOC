var structmcp79411__obj =
[
    [ "buffers", "structmcp79411__obj.html#a69609ddb192610a74d3226b8ccedcadb", null ],
    [ "rx_buffer", "structmcp79411__obj.html#a24ac3a6b7ce5ecf23a00aa367ff38557", null ],
    [ "tx_buffer", "structmcp79411__obj.html#ab5fe67d09d956bdf2bbbad468fcb3d92", null ]
];