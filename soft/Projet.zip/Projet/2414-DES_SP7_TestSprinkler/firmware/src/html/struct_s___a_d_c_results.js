var struct_s___a_d_c_results =
[
    [ "Chan0", "struct_s___a_d_c_results.html#afb94260a95482c919cde704e83a7587d", null ],
    [ "Chan1", "struct_s___a_d_c_results.html#a00b476dc1101396037182d19960bb58d", null ],
    [ "Chan10", "struct_s___a_d_c_results.html#ad171545f2a264b37e50217410caa9b94", null ],
    [ "Chan11", "struct_s___a_d_c_results.html#adc5625b61be26d5046d823c518dafc5f", null ],
    [ "Chan12", "struct_s___a_d_c_results.html#a52660a1a038ece5179aa347f3f9d8ff3", null ],
    [ "Chan13", "struct_s___a_d_c_results.html#a33032c7242c464af18b7568c055bc093", null ],
    [ "Chan14", "struct_s___a_d_c_results.html#ad0ba400a47dc72ed31e0460312b08caa", null ],
    [ "Chan2", "struct_s___a_d_c_results.html#aa6826129f4cc390b6b6b878a22bbe10d", null ],
    [ "Chan3", "struct_s___a_d_c_results.html#ac171207bc15d5ce117cb8fe19f29985e", null ],
    [ "Chan4", "struct_s___a_d_c_results.html#a92ec1a3371a4677d8c74d04e77a170f4", null ],
    [ "Chan5", "struct_s___a_d_c_results.html#a4523ff850903743d85e39f3b28fb506d", null ],
    [ "Chan6", "struct_s___a_d_c_results.html#a4014f21e2b7c1f3dfcbed7f238245ac6", null ],
    [ "Chan7", "struct_s___a_d_c_results.html#a9166273f3943fc3be1eaf48067f19e36", null ],
    [ "Chan8", "struct_s___a_d_c_results.html#a643dccbb5120ec6ec2fe2d474d3d3790", null ],
    [ "Chan9", "struct_s___a_d_c_results.html#af10debbe7d066ba835a7c9d22df8b2db", null ]
];