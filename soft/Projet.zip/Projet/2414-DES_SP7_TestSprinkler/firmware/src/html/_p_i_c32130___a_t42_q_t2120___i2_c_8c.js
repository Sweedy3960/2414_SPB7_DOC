var _p_i_c32130___a_t42_q_t2120___i2_c_8c =
[
    [ "AT42QT_Init", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#af5700399ec33af8803bb244e5f1b9667", null ],
    [ "AT42QT_Read", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#a9619655c3b6d6bc9d52e5da60515ad00", null ],
    [ "AT42QT_Read_Key0to7", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#a8d973579a3ad5f1718f8f1489ed8ebfe", null ],
    [ "AT42QT_Read_Key8to11", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#a39150e6230461628108aa0b9b349fc1a", null ],
    [ "AT42QT_Read_Wheel", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#a385915a2e3e17d17d3485357160cc161", null ],
    [ "AT42QT_Write", "_p_i_c32130___a_t42_q_t2120___i2_c_8c.html#ae8b864de4a507559ab0b1b82b82def6f", null ]
];