var struct_swithc_config =
[
    [ "state", "struct_swithc_config.html#a0b57aa10271a66f3dc936bba1d2f3830", null ]
];