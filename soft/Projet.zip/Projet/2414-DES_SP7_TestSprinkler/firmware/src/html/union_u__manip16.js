var union_u__manip16 =
[
    [ "lsb", "union_u__manip16.html#ac04c35971c92b7a0ddc152c107c02780", null ],
    [ "msb", "union_u__manip16.html#a3af713bb809b28be014ad661021590a8", null ],
    [ "shl", "union_u__manip16.html#a337f7b8b423d5e272adb3934b74b1400", null ],
    [ "val", "union_u__manip16.html#a757344f09097232d715d55cbf9d61a43", null ]
];