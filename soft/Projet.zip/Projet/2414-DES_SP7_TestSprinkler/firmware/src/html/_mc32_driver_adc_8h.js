var _mc32_driver_adc_8h =
[
    [ "S_ADCResults", "struct_s___a_d_c_results.html", "struct_s___a_d_c_results" ],
    [ "BSP_InitADC10", "_mc32_driver_adc_8h.html#ab8f2c4611b41e63055e35004ea2341e3", null ],
    [ "BSP_ReadAllADC", "_mc32_driver_adc_8h.html#a36f58dfc74e1e275e60c920f876974db", null ],
    [ "DRV_ADC_Open", "_mc32_driver_adc_8h.html#acc0c400e02d6ced6ac5552f9687386c7", null ],
    [ "DRV_ADC_SamplesAvailable", "_mc32_driver_adc_8h.html#a04eded505f95b03236b5c5052c66fb91", null ],
    [ "DRV_ADC_SamplesRead", "_mc32_driver_adc_8h.html#a61e35dbbc70ed4c9bce1c368fa6f10b0", null ],
    [ "DRV_ADC_Start", "_mc32_driver_adc_8h.html#a9b06f68a42771766770774e3302a1ffe", null ]
];