var struct_s___a_t42_q_t2120 =
[
    [ "start", "struct_s___a_t42_q_t2120.html#a7dc2499e4825a78e484bb388ab29dc1d", null ],
    [ "stop", "struct_s___a_t42_q_t2120.html#a219998cfb366307196d1013046d3f5d2", null ],
    [ "valKey0to7", "struct_s___a_t42_q_t2120.html#a5cca1cafe581f4e00d853992f5e28878", null ],
    [ "valKey8to11", "struct_s___a_t42_q_t2120.html#aff442d74b7de2acf677f72635bc681b3", null ],
    [ "valWheel", "struct_s___a_t42_q_t2120.html#af4f8e8c31e5cebf21fa7c2b11837d859", null ]
];