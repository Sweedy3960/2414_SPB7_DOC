var _driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h =
[
    [ "SERIAL_REG_DATA", "union_s_e_r_i_a_l___r_e_g___d_a_t_a.html", "union_s_e_r_i_a_l___r_e_g___d_a_t_a" ],
    [ "EXAMPLE_CONSTANT", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#a985d2a031a7f9fe12683d5b7ee1b8917", null ],
    [ "FCT_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5", [
      [ "ALARRM_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a05315116273220738fee255e6923e05a", null ],
      [ "ALARRM_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a3f96372346728d3c6867c35fc4126cd1", null ],
      [ "DERR_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a54ec300d87d8f01522b2296e11dc6aeb", null ],
      [ "DERR_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5ad7551ec6fe077ed9cd97e25726b3f4fc", null ],
      [ "FREE_IN1_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a54c090bc5bd7206b6d7edc5d7bc917b1", null ],
      [ "FREE_IN1_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5aaad3551c182041f8c9100b664fecf2e3", null ],
      [ "FREE_IN2_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5af46b40f61669999176731e35361a01da", null ],
      [ "FREE_IN2_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a8992582b4d69da8fe4c2a72c09373681", null ],
      [ "FREE_IN3_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a8d0e4b88baf572f20d3cdcec14a346ca", null ],
      [ "FREE_IN3_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a5cacff17709d7f10af515a55f1e22953", null ],
      [ "FREE_IN4_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a64516be305d52df7960c2d8f84e731a2", null ],
      [ "FREE_IN4_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5a561490f27a9954500a1f1ec8a10690d5", null ],
      [ "FREE_IN5_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5aa5610b4e7025a9d7cb8578be304ea589", null ],
      [ "FREE_IN5_LED_SAVE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5ac81a789f14ecb0be310cc20be145db5e", null ],
      [ "TEST_LED", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac77ecf9860eed32f92689772e20da5a5aec0233e73419754c4366f9de9fb5b5bd", null ]
    ] ],
    [ "SR_State", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac6a628dcd45de2a4051a0a68231bfefd", [
      [ "SR_IDLE", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac6a628dcd45de2a4051a0a68231bfefda8ab27fb2f3878a0f55e499681afe3f7a", null ],
      [ "SR_SHIFTING", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac6a628dcd45de2a4051a0a68231bfefda87edf73ac1fca1fa88a06deb864244dc", null ],
      [ "SR_LATCHING", "_driver___s_r___s_n74_h_c_s596_q_p_w_r_q1_8h.html#ac6a628dcd45de2a4051a0a68231bfefda5b75f28f728f2720b189d876b55a65cd", null ]
    ] ]
];