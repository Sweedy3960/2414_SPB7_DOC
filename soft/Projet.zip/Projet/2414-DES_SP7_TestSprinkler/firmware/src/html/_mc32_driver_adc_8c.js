var _mc32_driver_adc_8c =
[
    [ "configscan", "_mc32_driver_adc_8c.html#a3de0aed47ccfb1bb4d9bac72fe4989ab", null ],
    [ "BSP_InitADC10", "_mc32_driver_adc_8c.html#ab8f2c4611b41e63055e35004ea2341e3", null ],
    [ "BSP_ReadAllADC", "_mc32_driver_adc_8c.html#a36f58dfc74e1e275e60c920f876974db", null ]
];