var searchData=
[
  ['fifo_5frx_5fsize_0',['FIFO_RX_SIZE',['../_mc32gest___r_s232_8c.html#a131ae84ad3ae96195fb9306a3c8b8876',1,'Mc32gest_RS232.c']]],
  ['fifo_5ftx_5fsize_1',['FIFO_TX_SIZE',['../_mc32gest___r_s232_8c.html#ab69d26ca940cf09d48360806e1cd0d8e',1,'Mc32gest_RS232.c']]],
  ['firmware_5fversion_2',['FIRMWARE_VERSION',['../_p_i_c32130___a_t42_q_t2120___i2_c_8h.html#aa14dc39d52ab121ceb570f1a265385e0',1,'PIC32130_AT42QT2120_I2C.h']]]
];
