var searchData=
[
  ['oscrun_0',['OSCRUN',['../unionmcp79411___t_i_m_e___k_e_e_p_i_n_g.html#a9dba22a968a5bb0ad745f74c923bf647',1,'mcp79411_TIME_KEEPING']]],
  ['osctrim_5fbyte_1',['osctrim_byte',['../unionmcp79411___o_s_c_t_r_i_m.html#a6b477aa7c48b4a1e8c6e293a87c94d9f',1,'mcp79411_OSCTRIM']]],
  ['out_2',['OUT',['../unionmcp79411___c_o_n_t_r_o_l.html#a247b3e3bc75be4d1d80f1f5b19e21020',1,'mcp79411_CONTROL']]]
];
