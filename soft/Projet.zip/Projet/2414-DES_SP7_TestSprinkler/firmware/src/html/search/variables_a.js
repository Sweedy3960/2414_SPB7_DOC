var searchData=
[
  ['nbytesread_0',['nBytesRead',['../struct_a_p_p___f_a_t___d_a_t_a.html#a4c9da3da10333d10387341be2833e928',1,'APP_FAT_DATA']]],
  ['nbytestowrite_1',['nBytesToWrite',['../struct_a_p_p___f_a_t___d_a_t_a.html#a66eb867794f611877f71c96ef02941e0',1,'APP_FAT_DATA']]],
  ['nbyteswritten_2',['nBytesWritten',['../struct_a_p_p___f_a_t___d_a_t_a.html#add2640bdbd91f68492ba39b0e15e280c',1,'APP_FAT_DATA']]]
];
