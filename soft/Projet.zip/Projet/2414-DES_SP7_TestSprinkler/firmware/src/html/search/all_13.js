var searchData=
[
  ['u_5fmanip16_0',['U_manip16',['../union_u__manip16.html',1,'']]],
  ['usarthandle_1',['usartHandle',['../app_8c.html#ad6d17d48fdff77c90488018e4021b515',1,'app.c']]]
];
