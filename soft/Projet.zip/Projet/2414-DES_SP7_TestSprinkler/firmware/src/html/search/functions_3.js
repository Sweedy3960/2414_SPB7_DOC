var searchData=
[
  ['clocking_5fclk_0',['CLOCKING_CLK',['../app_8h.html#a83f72156f02ea0c9d1980998f6a1133e',1,'app.h']]],
  ['clocking_5fsrclk_1',['CLOCKING_SRCLK',['../app_8h.html#ae151403ee4e82e74bbd931fe9e0ff9e8',1,'app.h']]]
];
