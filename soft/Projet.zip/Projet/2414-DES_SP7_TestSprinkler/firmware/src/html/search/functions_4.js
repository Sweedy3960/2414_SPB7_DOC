var searchData=
[
  ['debuguart_5fprint_0',['DebugUART_Print',['../app_8c.html#ab90aceec1f83db2e42e1f207cd9e4c95',1,'DebugUART_Print(const char *format,...):&#160;app.c'],['../app_8h.html#ab90aceec1f83db2e42e1f207cd9e4c95',1,'DebugUART_Print(const char *format,...):&#160;app.c']]],
  ['drv_5fadc_5fopen_1',['DRV_ADC_Open',['../_mc32_driver_adc_8h.html#acc0c400e02d6ced6ac5552f9687386c7',1,'Mc32DriverAdc.h']]],
  ['drv_5fadc_5fsamplesavailable_2',['DRV_ADC_SamplesAvailable',['../_mc32_driver_adc_8h.html#a04eded505f95b03236b5c5052c66fb91',1,'Mc32DriverAdc.h']]],
  ['drv_5fadc_5fsamplesread_3',['DRV_ADC_SamplesRead',['../_mc32_driver_adc_8h.html#a61e35dbbc70ed4c9bce1c368fa6f10b0',1,'Mc32DriverAdc.h']]],
  ['drv_5fadc_5fstart_4',['DRV_ADC_Start',['../_mc32_driver_adc_8h.html#a9b06f68a42771766770774e3302a1ffe',1,'Mc32DriverAdc.h']]]
];
