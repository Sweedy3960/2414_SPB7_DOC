var unionmcp79411___o_s_c_t_r_i_m =
[
    [ "bits", "unionmcp79411___o_s_c_t_r_i_m.html#a78dde8bb622a2508db9dc7045afca960", null ],
    [ "osctrim_byte", "unionmcp79411___o_s_c_t_r_i_m.html#a6b477aa7c48b4a1e8c6e293a87c94d9f", null ],
    [ "SIGN", "unionmcp79411___o_s_c_t_r_i_m.html#a05ba1fc4ee8d9f0f700b3fd87d602513", null ],
    [ "TRIMVA", "unionmcp79411___o_s_c_t_r_i_m.html#aaa6c6615e4d868be9bab1ed881ec2d7e", null ]
];