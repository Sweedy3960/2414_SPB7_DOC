var _mc32___i2c_util_c_c_s_8h =
[
    [ "i2c_init", "_mc32___i2c_util_c_c_s_8h.html#ae66465ee5e1b6c243b89bf5eb84280ad", null ],
    [ "i2c_read", "_mc32___i2c_util_c_c_s_8h.html#a8665061bf5ef45de3774a98c6f8c0021", null ],
    [ "i2c_reStart", "_mc32___i2c_util_c_c_s_8h.html#a02bfecef74beba2239cf086fe53896a3", null ],
    [ "i2c_start", "_mc32___i2c_util_c_c_s_8h.html#af104fa2713ad2cfe4f993bdd2ec22c46", null ],
    [ "i2c_stop", "_mc32___i2c_util_c_c_s_8h.html#ad35d4e4f52ca74b503d5e5e1e0a3f5f3", null ],
    [ "i2c_write", "_mc32___i2c_util_c_c_s_8h.html#aa089a0bc7250c164c807807978c21fae", null ]
];