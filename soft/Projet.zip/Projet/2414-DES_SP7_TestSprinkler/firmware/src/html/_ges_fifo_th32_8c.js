var _ges_fifo_th32_8c =
[
    [ "GetCharFromFifo", "_ges_fifo_th32_8c.html#a3557f3b8c09b32667dcbb38d9d872bc6", null ],
    [ "GetReadSize", "_ges_fifo_th32_8c.html#a955713596c746a403b3c353c1e29668f", null ],
    [ "GetWriteSpace", "_ges_fifo_th32_8c.html#ab5464f5c735ba7e3be289d309a46eabb", null ],
    [ "InitFifo", "_ges_fifo_th32_8c.html#aeed954247aceee8fa793443163d52260", null ],
    [ "PutCharInFifo", "_ges_fifo_th32_8c.html#ae2a401c7dff876c69868f7a873426232", null ]
];