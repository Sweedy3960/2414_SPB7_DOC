var struct_stru_mess =
[
    [ "Angle", "struct_stru_mess.html#af6982c8e9ad797081e3b64b2ab6142ab", null ],
    [ "LsbCrc", "struct_stru_mess.html#a455dc883ed4260ac2ad529ccc2b06cab", null ],
    [ "MsbCrc", "struct_stru_mess.html#a30012831b2e63243451e14ac69a6e102", null ],
    [ "Speed", "struct_stru_mess.html#a482ce9c95c24cb0c3eb62c79356a2a8e", null ],
    [ "Start", "struct_stru_mess.html#aed5fc807f3a2beb548b30c2c2ef91f7b", null ]
];